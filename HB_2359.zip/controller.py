#!/usr/bin/env python3


# # Team ID:			[ HB_2359 ]
# # Author List:		[Sriram Thangavel, Sree Harish, Akshith, Prasannakumar]
# # Filename:			task_1.py
# # Functions:
# # 					[odometryCb(),task1_goals_Cb(),task1_goals_Cb(),main() ]
# # Nodes:		 		pub sub


import rospy

import time

# publishing to /cmd_vel with msg type: Twist
from geometry_msgs.msg import Twist

# subscribing to /odom with msg type: Odometry
from nav_msgs.msg import Odometry

# for finding sin() cos() 
import math

# Odometry is given as a quaternion, but for the controller we'll need to find the orientaion theta by converting to euler angle
from tf.transformations import euler_from_quaternion

from geometry_msgs.msg import PoseArray


hola_x = 0
hola_y = 0
hola_theta = 0

#desired goals
x_goals = [1, -1, -1, 1, 0]
y_goals = [1, 1, -1, -1, 0]
theta_goals = [math.pi/4, 3*math.pi/4, -3*math.pi/4, -math.pi/4, 0]


#callback function of /odom subscriber
def odometryCb(msg):
	global hola_x, hola_y, hola_theta

	hola_x = msg.pose.pose.position.x
	hola_y = msg.pose.pose.position.y
	q1 = msg.pose.pose.orientation.x
	q2 = msg.pose.pose.orientation.y
	q3 = msg.pose.pose.orientation.z
	q4 = msg.pose.pose.orientation.w
	q = (q1,q2,q3,q4)
	hola_theta = euler_from_quaternion(q)[2]

#callback function of task1_goals
def task1_goals_Cb(msg):
	global x_goals, y_goals, theta_goals

	x_goals.clear()
	y_goals.clear()
	theta_goals.clear()

	for waypoint_pose in msg.poses:
		x_goals.append(waypoint_pose.position.x)
		y_goals.append(waypoint_pose.position.y)

		orientation_q = waypoint_pose.orientation
		orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
		theta_goal = euler_from_quaternion (orientation_list)[2]
		theta_goals.append(theta_goal)


def main():

	rospy.init_node('controller',anonymous=True)

	pub = rospy.Publisher('/cmd_vel',Twist,queue_size=10)
	sub = rospy.Subscriber('/odom',Odometry,odometryCb)

	# declare that the node subscribes to task1_goals along with the other declarations of publishing and subscribing
	rospy.Subscriber('task1_goals', PoseArray, task1_goals_Cb)

	vel = Twist()


	rate = rospy.Rate(100)



	#kp value
	kp = 5.5

	index = 0
	
	while not rospy.is_shutdown():
		
		#errors in global frame
		x = x_goals[index] - hola_x
		y = y_goals[index] - hola_y
		theta = theta_goals[index] - hola_theta

		#velocity in global frame
		vel_x_g = kp*x
		vel_y_g = kp*y
		vel_z_g = kp*theta
		

		#velocity in body frame
		vel_x = vel_x_g*math.cos(hola_theta)+vel_y_g*math.sin(hola_theta)
		vel_y = -vel_x_g*math.sin(hola_theta)+vel_y_g*math.cos(hola_theta)
		vel_z = vel_z_g
		
		#publishing velocity
		vel.linear.x =vel_x
		vel.linear.y = vel_y
		vel.angular.z = vel_z
		pub.publish(vel)
		

		rate.sleep()

		if -0.04<=vel_x<=0.04:
			vel.linear.x =  0
			pub.publish(vel)
			
		

		if -0.04<=vel_y<=0.04:
			vel.linear.y = 0
			pub.publish(vel)
			

		if -0.004<=vel_z<=0.004:
			vel.angular.z = 0
			pub.publish(vel)
			
			

		if vel.linear.x == 0 and vel.linear.y == 0 and vel.angular.z == 0:
			print("Goal reached !!!!!")
			rospy.sleep(1)

			

			if index < len(x_goals)-1:
					index += 1

		
				

if __name__ == "__main__":
	try:
		main()
	except rospy.ROSInterruptException:
		pass